# Python Data Types

### LEARNING OBJECTIVES
*After this lesson, you will be able to:*
- Define integers, strings, tuples, lists, and dictionaries
- Demonstrate arithmetic operations and string operations
- Demonstrate variable assignment

### STUDENT PRE-WORK
*Before this lesson, you should already be able to:*
- Describe/define Python data types



